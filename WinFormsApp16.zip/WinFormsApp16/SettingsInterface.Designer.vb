﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SettingsInterface
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        components = New ComponentModel.Container()
        Dim CustomizableEdges7 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges8 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges9 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges10 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges11 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges12 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges13 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges14 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges15 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges16 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges3 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges4 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges5 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges6 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges1 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges2 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(SettingsInterface))
        Guna2BorderlessForm1 = New Guna.UI2.WinForms.Guna2BorderlessForm(components)
        Guna2Button7 = New Guna.UI2.WinForms.Guna2Button()
        Guna2Button6 = New Guna.UI2.WinForms.Guna2Button()
        Guna2Button5 = New Guna.UI2.WinForms.Guna2Button()
        Guna2Button4 = New Guna.UI2.WinForms.Guna2Button()
        Guna2Button1 = New Guna.UI2.WinForms.Guna2Button()
        Guna2Button2 = New Guna.UI2.WinForms.Guna2Button()
        Guna2Button3 = New Guna.UI2.WinForms.Guna2Button()
        Guna2Panel1 = New Guna.UI2.WinForms.Guna2Panel()
        SuspendLayout()
        ' 
        ' Guna2BorderlessForm1
        ' 
        Guna2BorderlessForm1.BorderRadius = 20
        Guna2BorderlessForm1.ContainerControl = Me
        Guna2BorderlessForm1.DockIndicatorTransparencyValue = 0.6R
        Guna2BorderlessForm1.DragForm = False
        Guna2BorderlessForm1.TransparentWhileDrag = True
        ' 
        ' Guna2Button7
        ' 
        Guna2Button7.BackColor = Color.Transparent
        Guna2Button7.BorderRadius = 10
        Guna2Button7.CustomizableEdges = CustomizableEdges7
        Guna2Button7.DisabledState.BorderColor = Color.DarkGray
        Guna2Button7.DisabledState.CustomBorderColor = Color.DarkGray
        Guna2Button7.DisabledState.FillColor = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        Guna2Button7.DisabledState.ForeColor = Color.FromArgb(CByte(141), CByte(141), CByte(141))
        Guna2Button7.FillColor = Color.FromArgb(CByte(209), CByte(66), CByte(66))
        Guna2Button7.Font = New Font("Segoe UI", 9F)
        Guna2Button7.ForeColor = Color.White
        Guna2Button7.Location = New Point(12, 598)
        Guna2Button7.Name = "Guna2Button7"
        Guna2Button7.ShadowDecoration.CustomizableEdges = CustomizableEdges8
        Guna2Button7.Size = New Size(309, 61)
        Guna2Button7.TabIndex = 12
        ' 
        ' Guna2Button6
        ' 
        Guna2Button6.BorderRadius = 10
        Guna2Button6.CustomizableEdges = CustomizableEdges9
        Guna2Button6.DisabledState.BorderColor = Color.DarkGray
        Guna2Button6.DisabledState.CustomBorderColor = Color.DarkGray
        Guna2Button6.DisabledState.FillColor = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        Guna2Button6.DisabledState.ForeColor = Color.FromArgb(CByte(141), CByte(141), CByte(141))
        Guna2Button6.FillColor = Color.White
        Guna2Button6.Font = New Font("Segoe UI", 9F)
        Guna2Button6.ForeColor = Color.White
        Guna2Button6.Location = New Point(12, 413)
        Guna2Button6.Name = "Guna2Button6"
        Guna2Button6.ShadowDecoration.CustomizableEdges = CustomizableEdges10
        Guna2Button6.Size = New Size(309, 61)
        Guna2Button6.TabIndex = 11
        ' 
        ' Guna2Button5
        ' 
        Guna2Button5.BorderRadius = 10
        Guna2Button5.CustomizableEdges = CustomizableEdges11
        Guna2Button5.DisabledState.BorderColor = Color.DarkGray
        Guna2Button5.DisabledState.CustomBorderColor = Color.DarkGray
        Guna2Button5.DisabledState.FillColor = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        Guna2Button5.DisabledState.ForeColor = Color.FromArgb(CByte(141), CByte(141), CByte(141))
        Guna2Button5.FillColor = Color.White
        Guna2Button5.Font = New Font("Segoe UI", 9F)
        Guna2Button5.ForeColor = Color.White
        Guna2Button5.Location = New Point(12, 333)
        Guna2Button5.Name = "Guna2Button5"
        Guna2Button5.ShadowDecoration.CustomizableEdges = CustomizableEdges12
        Guna2Button5.Size = New Size(309, 61)
        Guna2Button5.TabIndex = 10
        ' 
        ' Guna2Button4
        ' 
        Guna2Button4.BorderRadius = 10
        Guna2Button4.CustomizableEdges = CustomizableEdges13
        Guna2Button4.DisabledState.BorderColor = Color.DarkGray
        Guna2Button4.DisabledState.CustomBorderColor = Color.DarkGray
        Guna2Button4.DisabledState.FillColor = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        Guna2Button4.DisabledState.ForeColor = Color.FromArgb(CByte(141), CByte(141), CByte(141))
        Guna2Button4.FillColor = Color.White
        Guna2Button4.Font = New Font("Segoe UI", 9F)
        Guna2Button4.ForeColor = Color.White
        Guna2Button4.Location = New Point(12, 253)
        Guna2Button4.Name = "Guna2Button4"
        Guna2Button4.ShadowDecoration.CustomizableEdges = CustomizableEdges14
        Guna2Button4.Size = New Size(309, 61)
        Guna2Button4.TabIndex = 9
        ' 
        ' Guna2Button1
        ' 
        Guna2Button1.BorderRadius = 10
        Guna2Button1.CustomizableEdges = CustomizableEdges15
        Guna2Button1.DisabledState.BorderColor = Color.DarkGray
        Guna2Button1.DisabledState.CustomBorderColor = Color.DarkGray
        Guna2Button1.DisabledState.FillColor = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        Guna2Button1.DisabledState.ForeColor = Color.FromArgb(CByte(141), CByte(141), CByte(141))
        Guna2Button1.FillColor = Color.White
        Guna2Button1.Font = New Font("Segoe UI", 9F)
        Guna2Button1.ForeColor = Color.White
        Guna2Button1.Location = New Point(12, 173)
        Guna2Button1.Name = "Guna2Button1"
        Guna2Button1.ShadowDecoration.CustomizableEdges = CustomizableEdges16
        Guna2Button1.Size = New Size(309, 61)
        Guna2Button1.TabIndex = 8
        ' 
        ' Guna2Button2
        ' 
        Guna2Button2.BorderRadius = 10
        Guna2Button2.CustomizableEdges = CustomizableEdges3
        Guna2Button2.DisabledState.BorderColor = Color.DarkGray
        Guna2Button2.DisabledState.CustomBorderColor = Color.DarkGray
        Guna2Button2.DisabledState.FillColor = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        Guna2Button2.DisabledState.ForeColor = Color.FromArgb(CByte(141), CByte(141), CByte(141))
        Guna2Button2.FillColor = Color.White
        Guna2Button2.Font = New Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Guna2Button2.ForeColor = Color.FromArgb(CByte(11), CByte(78), CByte(147))
        Guna2Button2.Location = New Point(12, 253)
        Guna2Button2.Name = "Guna2Button2"
        Guna2Button2.PressedColor = Color.Transparent
        Guna2Button2.ShadowDecoration.CustomizableEdges = CustomizableEdges4
        Guna2Button2.Size = New Size(309, 61)
        Guna2Button2.TabIndex = 14
        Guna2Button2.Text = "SETTINGS"
        ' 
        ' Guna2Button3
        ' 
        Guna2Button3.BorderRadius = 10
        Guna2Button3.CustomizableEdges = CustomizableEdges5
        Guna2Button3.DisabledState.BorderColor = Color.DarkGray
        Guna2Button3.DisabledState.CustomBorderColor = Color.DarkGray
        Guna2Button3.DisabledState.FillColor = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        Guna2Button3.DisabledState.ForeColor = Color.FromArgb(CByte(141), CByte(141), CByte(141))
        Guna2Button3.FillColor = Color.White
        Guna2Button3.Font = New Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Guna2Button3.ForeColor = Color.FromArgb(CByte(11), CByte(78), CByte(147))
        Guna2Button3.Location = New Point(12, 173)
        Guna2Button3.Name = "Guna2Button3"
        Guna2Button3.PressedColor = Color.Transparent
        Guna2Button3.ShadowDecoration.CustomizableEdges = CustomizableEdges6
        Guna2Button3.Size = New Size(309, 61)
        Guna2Button3.TabIndex = 13
        Guna2Button3.Text = "DASHBOARD"
        ' 
        ' Guna2Panel1
        ' 
        Guna2Panel1.CustomizableEdges = CustomizableEdges1
        Guna2Panel1.FillColor = Color.White
        Guna2Panel1.Location = New Point(335, 66)
        Guna2Panel1.Name = "Guna2Panel1"
        Guna2Panel1.ShadowDecoration.CustomizableEdges = CustomizableEdges2
        Guna2Panel1.Size = New Size(906, 602)
        Guna2Panel1.TabIndex = 15
        ' 
        ' SettingsInterface
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), Image)
        ClientSize = New Size(1238, 668)
        Controls.Add(Guna2Panel1)
        Controls.Add(Guna2Button2)
        Controls.Add(Guna2Button3)
        Controls.Add(Guna2Button7)
        Controls.Add(Guna2Button6)
        Controls.Add(Guna2Button5)
        Controls.Add(Guna2Button4)
        Controls.Add(Guna2Button1)
        FormBorderStyle = FormBorderStyle.None
        Name = "SettingsInterface"
        Text = "SettingsInterface"
        ResumeLayout(False)
    End Sub

    Friend WithEvents Guna2BorderlessForm1 As Guna.UI2.WinForms.Guna2BorderlessForm
    Friend WithEvents Guna2Button7 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button6 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button5 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button4 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button1 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button2 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button3 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Panel1 As Guna.UI2.WinForms.Guna2Panel
End Class
