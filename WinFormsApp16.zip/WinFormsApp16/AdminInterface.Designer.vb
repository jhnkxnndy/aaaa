﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AdminInterface
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        components = New ComponentModel.Container()
        Dim CustomizableEdges11 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges12 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges9 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges10 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges7 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges8 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges5 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges6 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges3 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges4 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges1 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim CustomizableEdges2 As Guna.UI2.WinForms.Suite.CustomizableEdges = New Guna.UI2.WinForms.Suite.CustomizableEdges()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(AdminInterface))
        Guna2BorderlessForm1 = New Guna.UI2.WinForms.Guna2BorderlessForm(components)
        DashboardBtn = New Guna.UI2.WinForms.Guna2Button()
        Guna2Button3 = New Guna.UI2.WinForms.Guna2Button()
        Guna2Button4 = New Guna.UI2.WinForms.Guna2Button()
        Guna2Button5 = New Guna.UI2.WinForms.Guna2Button()
        SettingsBtn = New Guna.UI2.WinForms.Guna2Button()
        Guna2Panel1 = New Guna.UI2.WinForms.Guna2Panel()
        SuspendLayout()
        ' 
        ' Guna2BorderlessForm1
        ' 
        Guna2BorderlessForm1.BorderRadius = 20
        Guna2BorderlessForm1.ContainerControl = Me
        Guna2BorderlessForm1.DockIndicatorTransparencyValue = 0.6R
        Guna2BorderlessForm1.DragForm = False
        Guna2BorderlessForm1.TransparentWhileDrag = True
        ' 
        ' DashboardBtn
        ' 
        DashboardBtn.BorderRadius = 10
        DashboardBtn.CustomizableEdges = CustomizableEdges11
        DashboardBtn.DisabledState.BorderColor = Color.DarkGray
        DashboardBtn.DisabledState.CustomBorderColor = Color.DarkGray
        DashboardBtn.DisabledState.FillColor = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        DashboardBtn.DisabledState.ForeColor = Color.FromArgb(CByte(141), CByte(141), CByte(141))
        DashboardBtn.FillColor = Color.White
        DashboardBtn.Font = New Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        DashboardBtn.ForeColor = Color.FromArgb(CByte(11), CByte(78), CByte(147))
        DashboardBtn.Location = New Point(12, 173)
        DashboardBtn.Name = "DashboardBtn"
        DashboardBtn.PressedColor = Color.Transparent
        DashboardBtn.ShadowDecoration.CustomizableEdges = CustomizableEdges12
        DashboardBtn.Size = New Size(309, 61)
        DashboardBtn.TabIndex = 1
        DashboardBtn.Text = "DASHBOARD"
        ' 
        ' Guna2Button3
        ' 
        Guna2Button3.BorderRadius = 10
        Guna2Button3.CustomizableEdges = CustomizableEdges9
        Guna2Button3.DisabledState.BorderColor = Color.DarkGray
        Guna2Button3.DisabledState.CustomBorderColor = Color.DarkGray
        Guna2Button3.DisabledState.FillColor = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        Guna2Button3.DisabledState.ForeColor = Color.FromArgb(CByte(141), CByte(141), CByte(141))
        Guna2Button3.FillColor = Color.White
        Guna2Button3.Font = New Font("Segoe UI", 9F)
        Guna2Button3.ForeColor = Color.White
        Guna2Button3.Location = New Point(12, 333)
        Guna2Button3.Name = "Guna2Button3"
        Guna2Button3.ShadowDecoration.CustomizableEdges = CustomizableEdges10
        Guna2Button3.Size = New Size(309, 61)
        Guna2Button3.TabIndex = 5
        ' 
        ' Guna2Button4
        ' 
        Guna2Button4.BorderRadius = 10
        Guna2Button4.CustomizableEdges = CustomizableEdges7
        Guna2Button4.DisabledState.BorderColor = Color.DarkGray
        Guna2Button4.DisabledState.CustomBorderColor = Color.DarkGray
        Guna2Button4.DisabledState.FillColor = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        Guna2Button4.DisabledState.ForeColor = Color.FromArgb(CByte(141), CByte(141), CByte(141))
        Guna2Button4.FillColor = Color.White
        Guna2Button4.Font = New Font("Segoe UI", 9F)
        Guna2Button4.ForeColor = Color.White
        Guna2Button4.Location = New Point(12, 413)
        Guna2Button4.Name = "Guna2Button4"
        Guna2Button4.ShadowDecoration.CustomizableEdges = CustomizableEdges8
        Guna2Button4.Size = New Size(309, 61)
        Guna2Button4.TabIndex = 6
        ' 
        ' Guna2Button5
        ' 
        Guna2Button5.BackColor = Color.Transparent
        Guna2Button5.BorderRadius = 10
        Guna2Button5.CustomizableEdges = CustomizableEdges5
        Guna2Button5.DisabledState.BorderColor = Color.DarkGray
        Guna2Button5.DisabledState.CustomBorderColor = Color.DarkGray
        Guna2Button5.DisabledState.FillColor = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        Guna2Button5.DisabledState.ForeColor = Color.FromArgb(CByte(141), CByte(141), CByte(141))
        Guna2Button5.FillColor = Color.FromArgb(CByte(209), CByte(66), CByte(66))
        Guna2Button5.Font = New Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Guna2Button5.ForeColor = Color.White
        Guna2Button5.Location = New Point(12, 598)
        Guna2Button5.Name = "Guna2Button5"
        Guna2Button5.ShadowDecoration.CustomizableEdges = CustomizableEdges6
        Guna2Button5.Size = New Size(309, 61)
        Guna2Button5.TabIndex = 7
        Guna2Button5.Text = "LOG OUT"
        ' 
        ' SettingsBtn
        ' 
        SettingsBtn.BorderRadius = 10
        SettingsBtn.CustomizableEdges = CustomizableEdges3
        SettingsBtn.DisabledState.BorderColor = Color.DarkGray
        SettingsBtn.DisabledState.CustomBorderColor = Color.DarkGray
        SettingsBtn.DisabledState.FillColor = Color.FromArgb(CByte(169), CByte(169), CByte(169))
        SettingsBtn.DisabledState.ForeColor = Color.FromArgb(CByte(141), CByte(141), CByte(141))
        SettingsBtn.FillColor = Color.White
        SettingsBtn.Font = New Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        SettingsBtn.ForeColor = Color.FromArgb(CByte(11), CByte(78), CByte(147))
        SettingsBtn.Location = New Point(12, 253)
        SettingsBtn.Name = "SettingsBtn"
        SettingsBtn.PressedColor = Color.Transparent
        SettingsBtn.ShadowDecoration.CustomizableEdges = CustomizableEdges4
        SettingsBtn.Size = New Size(309, 61)
        SettingsBtn.TabIndex = 8
        SettingsBtn.Text = "SETTINGS"
        ' 
        ' Guna2Panel1
        ' 
        Guna2Panel1.CustomizableEdges = CustomizableEdges1
        Guna2Panel1.FillColor = Color.White
        Guna2Panel1.Location = New Point(334, 0)
        Guna2Panel1.Name = "Guna2Panel1"
        Guna2Panel1.ShadowDecoration.CustomizableEdges = CustomizableEdges2
        Guna2Panel1.Size = New Size(907, 669)
        Guna2Panel1.TabIndex = 9
        ' 
        ' AdminInterface
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), Image)
        ClientSize = New Size(1238, 668)
        Controls.Add(Guna2Panel1)
        Controls.Add(SettingsBtn)
        Controls.Add(Guna2Button5)
        Controls.Add(Guna2Button4)
        Controls.Add(Guna2Button3)
        Controls.Add(DashboardBtn)
        FormBorderStyle = FormBorderStyle.None
        Name = "AdminInterface"
        StartPosition = FormStartPosition.CenterScreen
        Text = "AdminInterface"
        ResumeLayout(False)
    End Sub

    Friend WithEvents Guna2BorderlessForm1 As Guna.UI2.WinForms.Guna2BorderlessForm
    Friend WithEvents DashboardBtn As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button5 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button4 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button3 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents SettingsBtn As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Panel1 As Guna.UI2.WinForms.Guna2Panel
End Class
