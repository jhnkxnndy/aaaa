﻿Imports Guna.UI2.WinForms

Public Class AdminInterface

    Private Sub DashboardBtn_Click(sender As Object, e As EventArgs) Handles DashboardBtn.Click
        DashboardInterface.TopLevel = False
        Guna2Panel1.Controls.Add(DashboardInterface)
        DashboardInterface.Show()
        DashboardInterface.BringToFront()

        DashboardBtn.FillColor = Color.FromArgb(43, 78, 116)
        DashboardBtn.ForeColor = Color.White

        SettingsBtn.FillColor = Color.White
        SettingsBtn.ForeColor = Color.FromArgb(43, 78, 116)
    End Sub

    Private Sub SettingsBtn_Click(sender As Object, e As EventArgs) Handles SettingsBtn.Click
        SettingsInterface.TopLevel = False
        Guna2Panel1.Controls.Add(SettingsInterface)
        SettingsInterface.Show()
        SettingsInterface.BringToFront()

        DashboardBtn.FillColor = Color.White
        DashboardBtn.ForeColor = Color.FromArgb(43, 78, 116)

        SettingsBtn.FillColor = Color.FromArgb(43, 78, 116)
        SettingsBtn.ForeColor = Color.White
    End Sub
End Class