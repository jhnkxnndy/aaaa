﻿Imports Guna.UI2.WinForms

Public Class SettingsInterface

End Class